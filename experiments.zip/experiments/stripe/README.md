!["Stripe" target product](./target.png?raw=true "'Stripe' target product")

The target product illustrated in the figure above is an epithelial cells layer having thickness equal to 20.<, placed on top of an extracellular matrix (ECM) layer having thickness equal to 3 (not shown in figure). Cells are represented in blue, while a red and a green dot help figure out the orientation.

> The configuration files in this folder do not contain meaningful values for the parameters. They are just meant as a template for you to play with and to illustrate how to build target geometries.
